// src/routes/paths.js
export const PATHS = {
  ROOT: '/',
  SIGN_IN: '/signin',
  DASHBOARD: '/dashboard',
};
